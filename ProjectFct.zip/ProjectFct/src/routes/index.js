const router = require('express').Router();
const passport = require('passport');
const Alumno = require('../models/alumno');
const Empresa = require('../models/empresa');
const Centro = require('../models/centro');

router.get('/', (req, res, next) => {
  res.render('index');
});

router.get('/alumnos',(req,res)=>{
  res.render('alumnos'); 
}); 
router.post('/alumnos',async (req,res)=>{
  //Guardado de Alumno
  const{nombre,primerApellido, segundoApellido,centro,ciclo,fechaInicio,fechaFin,dni}=req.body 
  const errors=[];     
  if(!nombre){errors.push({text:'Porfavor escribe un nombre'})}     
  if(!primerApellido){errors.push({text:'Porfavor escribe un apellido'})}
  if(!segundoApellido){errors.push({text:'Porfavor escribe un apellido'})}
  if(!centro){errors.push({text:'Porfavor escribe un centro'})}
  if(!ciclo){errors.push({text:'Porfavor escribe un tutor'})}
  if(!fechaInicio){errors.push({text:'Porfavor escribe una Fecha'})}
  if(!fechaFin){errors.push({text:'Porfavor escribe una Fecha'})}
  if(!dni){errors.push({text:'Porfavor escribe un Dni'})}
  if(errors.length>0){res.render('alumnos',{errors,nombre,primerApellido, segundoApellido,centro,ciclo,fechaInicio,fechaFin,dni});   
  }else{const newAlumno=new Alumno({nombre,primerApellido, segundoApellido,centro,ciclo,fechaInicio,fechaFin,dni})
  await newAlumno.save();
  req.flash('success_msg','Alumno Añadido')
  res.redirect('/alumnos')}
});

  router.get('/empresas',(req,res)=>{
    res.render('empresas'); 
  }); 
  router.post('/empresas',async (req,res)=>{
  const{nombreEmpresa,responsable,nif,domiciliacion,provincia,pais,calle,cp,cif,telefono}=req.body 
  const error=[];     
  if(!nombreEmpresa){error.push({text:'Porfavor escribe un nombre'})}
  if(!responsable){error.push({text:'Porfavor escribe un nombre de responsable'})}
  if(!nif){error.push({text:'Porfavor escribe un nif'})}
  if(!domiciliacion){error.push({text:'Porfavor escribe una domiciliacion'})}
  if(!provincia){error.push({text:'Porfavor escribe una provincia'})}
  if(!pais){error.push({text:'Porfavor escribe un pais'})}
  if(!calle){error.push({text:'Porfavor escribe una calle'})}
  if(!cp){error.push({text:'Porfavor escribe un cp'})}
  if(!cif){error.push({text:'Porfavor escribe un cif'})}
  if(!telefono){error.push({text:'Porfavor escribe un telefono'})}
  if(error.length>0){res.render('empresas',{error,nombreEmpresa,responsable,nif,domiciliacion,provincia,pais,calle,cp,cif,telefono});   
  }else{const newEmpresa =new Empresa({nombreEmpresa,responsable,nif,domiciliacion,provincia,pais,calle,cp,cif,telefono})
  await newEmpresa.save();
  req.flash('success_msg','Empresa Añadida')
  res.redirect('/empresas')}
});
  
router.get('/centros',(req,res)=>{
  res.render('centros'); 
}); 
router.post('/centros',async (req,res)=>{
const{nombreCentro, nombreProfesor, familiaProfesional,nombreDirector, nifCentro,ubicacion,
  calleCentro,codigoCentro,codigoPostal,cifCentro,numeroTelefono}=req.body 
const error=[];     
if(!nombreCentro){error.push({text:'Porfavor escribe un nombre del centro'})}
if(!nombreDirector){error.push({text:'Porfavor escribe un nombre director'})}
if(!nifCentro){error.push({text:'Porfavor escribe un cif centro'})}
if(!ubicacion){error.push({text:'Porfavor escribe una ubicacion'})}
if(!calleCentro){error.push({text:'Porfavor escribe una calle'})}
if(!codigoCentro){error.push({text:'Porfavor escribe un codigo'})}
if(!codigoPostal){error.push({text:'Porfavor escribe un codigo posta'})}
if(!cifCentro){error.push({text:'Porfavor escribe un cif'})}
if(!numeroTelefono){error.push({text:'Porfavor escribe un numeroTelefono'})}
if(error.length>0){res.render('centros',{error,nombreCentro, nombreProfesor, familiaProfesional,nombreDirector, nifCentro,ubicacion,
  calleCentro,codigoCentro,codigoPostal,cifCentro,numeroTelefono});   
}else{const newCentro =new Centro({nombreCentro, nombreProfesor, familiaProfesional,nombreDirector, nifCentro,ubicacion,
  calleCentro,codigoCentro,codigoPostal,cifCentro,numeroTelefono})
await newCentro.save();
req.flash('success_msg','Empresa Añadida')
res.redirect('/centros')}
});


router.get('/signup', (req, res, next) => {
  res.render('signup');
});

router.post('/signup', passport.authenticate('local-signup', {
  successRedirect: '/profile',
  failureRedirect: '/signup',
  failureFlash: true
})); 

router.get('/signin', (req, res, next) => {
  res.render('signin');
});


router.post('/signin', passport.authenticate('local-signin', {
  successRedirect: '/profile',
  failureRedirect: '/signin',
  failureFlash: true
}));

router.get('/profile',isAuthenticated, (req, res, next) => {
  res.render('profile');
});

router.get('/logout', (req, res, next) => {
  req.logout('');
  res.redirect('/');
});


function isAuthenticated(req, res, next) {
  if(req.isAuthenticated()) {
    return next();
  }

  res.redirect('/')
}

module.exports = router;
