const mongoose=require('mongoose'); 
const {Schema}=mongoose;  
const centroSchema=new Schema({     
    nombreCentro:{type:String,required:true},     
    nombreProfesor:{type:String,required:false},
    familiaProfesional:{type:String,require:false},    
    nombreDirector:{type:String,require:true},
    nifCentro:{type:String,require:true},
    ubicacion:{type:String,require:true},
    calle:{type:String,require:true},
    codigoCentro:{type:String,require:true},
    codigoPostal:{type:String,require:true},
    cifCentro:{type:String,require:true},
    numeroTelefono:{type:String,require:true},
}); 
module.exports = mongoose.model('centro', centroSchema);