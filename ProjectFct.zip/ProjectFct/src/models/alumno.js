const mongoose=require('mongoose'); 
const {Schema}=mongoose;  
const alumnoSchema=new Schema({     
    nombre:{type:String,required:true},     
    primerApellido:{type:String,required:true},
    segundoApellido:{type:String,require:true},    
    centro:{type:String,require:true},
    ciclo:{type:String,require:true},
    fechaInicio:{type:Date,require:true},
    fechaFin:{type:Date,require:true},
    dni:{type:String,require:true}
}); 
module.exports = mongoose.model('alumno', alumnoSchema);