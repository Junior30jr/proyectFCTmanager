const mongoose=require('mongoose'); 
const {Schema}=mongoose;  
const empresaSchema=new Schema({     
    nombreEmpresa:{type:String,required:true},     
    responsable:{type:String,required:true},
    nif:{type:String,required:true},
    domiciliacion:{type:String,required:true},
    provincia:{type:String,required:true},
    pais:{type:String,required:true},
    calle:{type:String,required:true},
    cp:{type:String,required:true},
    cif:{type:String,required:true},
    telefono:{type:String,required:true}

}); 
module.exports = mongoose.model('empresa', empresaSchema);