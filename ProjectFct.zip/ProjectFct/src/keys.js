module.exports = {
  mongodb: {
    URI: 'mongodb+srv://admin:admin@cluster0.o9gjf.mongodb.net/?retryWrites=true&w=majority'
  }
};
