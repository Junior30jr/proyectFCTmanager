const express = require('express');
const path = require('path');
const flash = require('connect-flash');
const session = require('express-session');
const passport = require('passport');
const morgan = require('morgan');

// initializations
const app = express();
require('./database');
require('./passport/local-auth');

// settings
app.set('port', process.env.PORT || 4200);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// middlewares
app.use(morgan('dev'));
app.use(express.urlencoded({extended: false}));
app.use(session({
  secret: 'mysecretsession',
  resave: false,
  saveUninitialized: false
}));
app.use(flash());
app.use(passport.initialize());
app.use(passport.session());

app.use((req, res, next) => {
  res.locals.signinMessage = req.flash('signinMessage');
  res.locals.signupMessage = req.flash('signupMessage');
  res.locals.registerMessage = req.flash('registerMessage');
  res.locals.success_msg=req.flash('success_msg')     
  res.locals.error_msg=req.flash('error_msg')     
  res.locals.error=req.flash('error')    
  res.locals.user = req.user;
  res.locals.alumno = req.alumno;
  console.log(app.locals)
  next();
});


// routes
app.use('/', require('./routes/index'));

//archivos dinamicos
app.use(express.static(path.join(__dirname, 'public')));

// Starting the server
app.listen(app.get('port'), () => {
  console.log('server on port', app.get('port'));
});
